#pragma comment(lib, "ws2_32")
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <iostream>


#define SERVERPORT	9999
#define BUFSIZE		256


using namespace std;

int main()
{
	int retVal;

	// ���� �ʱ�ȭ
	WSADATA wsa;
	retVal = WSAStartup(MAKEWORD(2, 2), &wsa);
	if (retVal != 0)
	{
		printf("error WSAStartup() %d\n", retVal);
		return 1;
	}

	// listen socket
	SOCKET listenSock = socket(AF_INET, SOCK_STREAM, 0);
	if (listenSock == INVALID_SOCKET)
	{
		printf("error listen socket()\n");
		return 1;
	}

	// bind
	SOCKADDR_IN serverAddr;
	ZeroMemory(&serverAddr, sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVERPORT);
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	retVal = bind(listenSock, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
	if (retVal == SOCKET_ERROR)
	{
		printf("error bind()\n");
		return 1;
	}

	// listen
	retVal = listen(listenSock, SOMAXCONN);
	if (retVal == SOCKET_ERROR)
	{
		printf("error listen()\n");
		return 1;
	}

	SOCKET clientSock;
	SOCKADDR_IN clientAddr;
	int addrLen;

	puts("accept()");
	addrLen = sizeof(clientAddr);
	clientSock = accept(listenSock, (SOCKADDR*)&clientAddr, &addrLen);

	if (clientSock == INVALID_SOCKET)
	{
		printf("error accept()\n");
	}
	else
	{
		char buf[16];
		inet_ntop(AF_INET, &clientAddr.sin_addr, buf, sizeof(buf));
		printf("[TCP ����] Ŭ���̾�Ʈ ���� : IP �ּ� = %s, ��Ʈ ��ȣ = %d\n", buf, ntohs(clientAddr.sin_port));
	}

	char recvBuf[BUFSIZE];
	retVal = recv(clientSock, recvBuf, sizeof(recvBuf), 0);
	while (1)
	{
		if (retVal == 0 || retVal == SOCKET_ERROR)
		{
			closesocket(clientSock);
		}
		else
		{
			for (int i = 0; i < retVal; i++)
			{
				cout << recvBuf[i];
			}
			cout << endl;
		}
	}



	WSACleanup();
	return 0;
}